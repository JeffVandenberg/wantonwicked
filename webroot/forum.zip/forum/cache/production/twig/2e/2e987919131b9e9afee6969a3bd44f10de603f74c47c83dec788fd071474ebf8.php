<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @senky_removesubjectfromreplies/event/viewtopic_body_post_subject_before.html */
class __TwigTemplate_769fdb2759cafed7049e598453f05a54c500cd5c57f0d9b55c1af1670e322dfc extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if ( !$this->getAttribute(($context["postrow"] ?? null), "S_FIRST_ROW", [])) {
            // line 2
            echo "<div class=\"hidden\">
";
        }
    }

    public function getTemplateName()
    {
        return "@senky_removesubjectfromreplies/event/viewtopic_body_post_subject_before.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@senky_removesubjectfromreplies/event/viewtopic_body_post_subject_before.html", "");
    }
}
