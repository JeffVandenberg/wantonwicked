<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blank_layout4.tpl */
class __TwigTemplate_c84559bffa5f1b73b5a81241f884607a8f09ccc44395a6c5eb4599f10e3acd95 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>
    <title>";
        // line 5
        echo ($context["PAGE_TITLE"] ?? null);
        echo "</title>
    <META NAME=\"copyright\" content=\"(c) 2013 Jeff Vandenberg\">
    <META NAME=\"ROBOTS\" CONTENT=\"noimageindex,follow\">
    <link type=\"text/css\" href=\"css/ww5.css\" rel=\"Stylesheet\"/>
    <link type=\"text/css\" href=\"css/gaming-sandbox.css\" rel=\"Stylesheet\"/>
    <link type=\"text/css\" href=\"css/wanton/jquery-ui.min.css\" rel=\"stylesheet\"/>
    <link type=\"text/css\" href=\"css/wanton/jquery.ui.menubar.css\" rel=\"stylesheet\"/>
    <script type=\"text/javascript\" src=\"js/jquery-1.11.3.min.js\"></script>
    <script type=\"text/javascript\" src=\"js/jquery-ui.min.js\"></script>
    <script type=\"text/javascript\" src=\"js/jquery.ui.menubar.js\"></script>
    <script type=\"text/javascript\" src=\"js/wanton.js\"></script>
    ";
        // line 16
        echo ($context["EXTRA_HEADERS"] ?? null);
        echo "
</head>
";
        // line 18
        echo ($context["JAVA_SCRIPT"] ?? null);
        echo "
<body>
<div class=\"content-box\">
    <div class=\"box-header\">
        ";
        // line 22
        echo ($context["CONTENT_HEADER"] ?? null);
        echo "
    </div>
    <div class=\"box-content\">
        ";
        // line 25
        echo ($context["PAGE_CONTENT"] ?? null);
        echo "
    </div>
</div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "blank_layout4.tpl";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 25,  62 => 22,  55 => 18,  50 => 16,  36 => 5,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "blank_layout4.tpl", "");
    }
}
