<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @marttiphpbb_postingtemplate/event/acp_forums_main_settings_append.html */
class __TwigTemplate_441764436726e3ffca30d91c56866e7fb6251abcead9f42f88ce8a8ae2fde23c extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if (($context["S_FORUM_POST"] ?? null)) {
            // line 2
            echo "<dl>
\t<dt><label for=\"forum_postingtemplate\">";
            // line 3
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ACP_POSTINGTEMPLATE");
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
            echo "</label><br /><span>";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ACP_POSTINGTEMPLATE_EXPLAIN");
            echo "</span></dt>
\t<dd><textarea id=\"forum_postingtemplate\" name=\"forum_postingtemplate\" rows=\"5\" cols=\"45\" data-bbcode=\"true\">";
            // line 4
            echo ($context["FORUM_POSTINGTEMPLATE"] ?? null);
            echo "</textarea></dd>
</dl>
";
        }
    }

    public function getTemplateName()
    {
        return "@marttiphpbb_postingtemplate/event/acp_forums_main_settings_append.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 4,  35 => 3,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@marttiphpbb_postingtemplate/event/acp_forums_main_settings_append.html", "");
    }
}
