<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* captcha_recaptcha.html */
class __TwigTemplate_0775b3e701c28bb4d22d7440de31e786c5ebde9fe29aa59bd7045086ba76b85f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if ((($context["S_TYPE"] ?? null) == 1)) {
            // line 2
            echo "<div class=\"panel captcha-panel\">
\t<div class=\"inner\">

\t<h3 class=\"captcha-title\">";
            // line 5
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CONFIRMATION");
            echo "</h3>
\t<p>";
            // line 6
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CONFIRM_EXPLAIN");
            echo "</p>

\t<fieldset class=\"fields2\">
";
        }
        // line 10
        echo "
";
        // line 11
        if (($context["S_RECAPTCHA_AVAILABLE"] ?? null)) {
            // line 12
            echo "\t<dl>
\t<dt><label>";
            // line 13
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CONFIRM_CODE");
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
            echo "</label><br /><span>";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RECAPTCHA_EXPLAIN");
            echo "</span></dt>
\t<dd class=\"captcha\">
\t\t<noscript>
\t\t\t<div>";
            // line 16
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RECAPTCHA_NOSCRIPT");
            echo "</div>
\t\t</noscript>
\t\t<script src=\"";
            // line 18
            echo ($context["RECAPTCHA_SERVER"] ?? null);
            echo ".js?hl=";
            echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("RECAPTCHA_LANG"), "js");
            echo "\" async defer></script>
\t\t<div class=\"g-recaptcha\" data-sitekey=\"";
            // line 19
            echo ($context["RECAPTCHA_PUBKEY"] ?? null);
            echo "\" data-tabindex=\"";
            if ($this->getAttribute(($context["definition"] ?? null), "CAPTCHA_TAB_INDEX", [])) {
                echo $this->getAttribute(($context["definition"] ?? null), "CAPTCHA_TAB_INDEX", []);
            } else {
                echo "10";
            }
            echo "\"></div>
\t</dd>
\t</dl>
";
        } else {
            // line 23
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RECAPTCHA_NOT_AVAILABLE");
            echo "
";
        }
        // line 25
        echo "
";
        // line 26
        if ((($context["S_TYPE"] ?? null) == 1)) {
            // line 27
            echo "\t</fieldset>
\t</div>
</div>
";
        }
    }

    public function getTemplateName()
    {
        return "captcha_recaptcha.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 27,  97 => 26,  94 => 25,  89 => 23,  76 => 19,  70 => 18,  65 => 16,  56 => 13,  53 => 12,  51 => 11,  48 => 10,  41 => 6,  37 => 5,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "captcha_recaptcha.html", "");
    }
}
