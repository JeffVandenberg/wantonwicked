<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* acp_users_avatar.html */
class __TwigTemplate_d71d542a4ac00633818d3771e1aa1c6a089bbfef6308b50f1aa23be143a3c9c7 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "\t<form id=\"avatar_settings\" method=\"post\" action=\"";
        echo ($context["U_ACTION"] ?? null);
        echo "\" enctype=\"multipart/form-data\">

\t<fieldset>
\t\t<legend>";
        // line 4
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ACP_USER_AVATAR");
        echo "</legend>
\t";
        // line 5
        if (($context["ERROR"] ?? null)) {
            echo "<p class=\"error\">";
            echo ($context["ERROR"] ?? null);
            echo "</p>";
        }
        // line 6
        echo "\t\t<dl>
\t\t\t<dt><label>";
        // line 7
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("CURRENT_IMAGE");
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
        echo "</label><br /><span>";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("AVATAR_EXPLAIN");
        echo "</span></dt>
\t\t\t<dd>";
        // line 8
        echo ($context["AVATAR"] ?? null);
        echo "</dd>
\t\t\t<dd><label for=\"avatar_delete\"><input type=\"checkbox\" name=\"avatar_delete\" id=\"avatar_delete\" /> ";
        // line 9
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_AVATAR");
        echo "</label></dd>
\t\t</dl>
\t</fieldset>
\t<fieldset>
\t\t<legend>";
        // line 13
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("AVATAR_SELECT");
        echo "</legend>
\t\t<dl>
\t\t\t<dt><label>";
        // line 15
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("AVATAR_TYPE");
        echo "</label></dt>
\t\t\t<dd><select name=\"avatar_driver\" id=\"avatar_driver\" data-togglable-settings=\"true\">
\t\t\t\t";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["loops"] ?? null), "avatar_drivers", []));
        foreach ($context['_seq'] as $context["_key"] => $context["avatar_drivers"]) {
            // line 18
            echo "\t\t\t\t<option value=\"";
            echo $this->getAttribute($context["avatar_drivers"], "DRIVER", []);
            echo "\"";
            if ($this->getAttribute($context["avatar_drivers"], "SELECTED", [])) {
                echo " selected=\"selected\"";
            }
            echo " data-toggle-setting=\"#avatar_option_";
            echo $this->getAttribute($context["avatar_drivers"], "DRIVER", []);
            echo "\">";
            echo $this->getAttribute($context["avatar_drivers"], "L_TITLE", []);
            echo "</option>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['avatar_drivers'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "\t\t\t</select></dd>
\t\t</dl>
\t\t<div id=\"avatar_options\">
\t\t";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["loops"] ?? null), "avatar_drivers", []));
        foreach ($context['_seq'] as $context["_key"] => $context["avatar_drivers"]) {
            // line 24
            echo "\t\t\t<div id=\"avatar_option_";
            echo $this->getAttribute($context["avatar_drivers"], "DRIVER", []);
            echo "\">
\t\t\t\t<p>";
            // line 25
            echo $this->getAttribute($context["avatar_drivers"], "L_EXPLAIN", []);
            echo "</p>
\t\t\t\t";
            // line 26
            echo $this->getAttribute($context["avatar_drivers"], "OUTPUT", []);
            echo "
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['avatar_drivers'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "\t\t</div>
\t</fieldset>

\t<fieldset class=\"quick\">
\t\t<input type=\"submit\" name=\"update\" value=\"";
        // line 33
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SUBMIT");
        echo "\" class=\"button1\" />
\t";
        // line 34
        echo ($context["S_FORM_TOKEN"] ?? null);
        echo "
\t</fieldset>
\t</form>
";
    }

    public function getTemplateName()
    {
        return "acp_users_avatar.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 34,  132 => 33,  126 => 29,  117 => 26,  113 => 25,  108 => 24,  104 => 23,  99 => 20,  82 => 18,  78 => 17,  73 => 15,  68 => 13,  61 => 9,  57 => 8,  50 => 7,  47 => 6,  41 => 5,  37 => 4,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "acp_users_avatar.html", "");
    }
}
