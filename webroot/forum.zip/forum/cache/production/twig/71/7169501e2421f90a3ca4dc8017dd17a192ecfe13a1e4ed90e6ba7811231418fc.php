<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* drafts.html */
class __TwigTemplate_fb5e620d9fe74f565cd059a81288e0c67f0969296c1047aaabbc6b7e4b332de8 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "

";
        // line 3
        if (twig_length_filter($this->env, $this->getAttribute(($context["loops"] ?? null), "draftrow", []))) {
            // line 4
            echo "<div class=\"panel\">
\t<div class=\"inner\">

\t<h3 class=\"draft-title\">";
            // line 7
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
            echo "</h3>
\t<p>";
            // line 8
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT_EXPLAIN");
            echo "</p>

\t</div>
</div>

<div class=\"";
            // line 13
            if ( !($context["S_PRIVMSGS"] ?? null)) {
                echo "forumbg";
            } else {
                echo "panel";
            }
            echo "\">
\t<div class=\"inner\">

\t<ul class=\"topiclist two-long-columns\">
\t\t<li class=\"header\">
\t\t\t<dl>
\t\t\t\t<dt>";
            // line 19
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
            echo "</dt>
\t\t\t\t<dd class=\"info\">";
            // line 20
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SAVE_DATE");
            echo "</dd>
\t\t\t</dl>
\t\t</li>
\t</ul>
\t<ul class=\"topiclist two-long-columns";
            // line 24
            if ( !($context["S_PRIVMSGS"] ?? null)) {
                echo " topics";
            } else {
                echo " cplist";
            }
            echo "\">

\t";
            // line 26
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["loops"] ?? null), "draftrow", []));
            foreach ($context['_seq'] as $context["_key"] => $context["draftrow"]) {
                // line 27
                echo "\t<li class=\"row";
                if (($this->getAttribute($context["draftrow"], "S_ROW_COUNT", []) % 2 == 0)) {
                    echo " bg1";
                } else {
                    echo " bg2";
                }
                echo "\">
\t\t<dl>
\t\t\t<dt>
\t\t\t\t<div class=\"list-inner\">
\t\t\t\t\t<a href=\"";
                // line 31
                echo $this->getAttribute($context["draftrow"], "U_INSERT", []);
                echo "\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOAD_DRAFT");
                echo "\" class=\"topictitle\">";
                echo $this->getAttribute($context["draftrow"], "DRAFT_SUBJECT", []);
                echo "</a><br />
\t\t\t\t\t";
                // line 32
                if ( !($context["S_PRIVMSGS"] ?? null)) {
                    if ($this->getAttribute($context["draftrow"], "S_LINK_TOPIC", [])) {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC");
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
                        echo " <a href=\"";
                        echo $this->getAttribute($context["draftrow"], "U_VIEW", []);
                        echo "\">";
                        echo $this->getAttribute($context["draftrow"], "TITLE", []);
                        echo "</a>
\t\t\t\t\t";
                    } elseif ($this->getAttribute(                    // line 33
$context["draftrow"], "S_LINK_FORUM", [])) {
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
                        echo " <a href=\"";
                        echo $this->getAttribute($context["draftrow"], "U_VIEW", []);
                        echo "\">";
                        echo $this->getAttribute($context["draftrow"], "TITLE", []);
                        echo "</a>
\t\t\t\t\t";
                    } else {
                        // line 34
                        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPIC_FORUM");
                    }
                }
                // line 35
                echo "\t\t\t\t\t<div class=\"responsive-show\" style=\"display: none;\">
\t\t\t\t\t\t";
                // line 36
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SAVE_DATE");
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
                echo " <strong>";
                echo $this->getAttribute($context["draftrow"], "DATE", []);
                echo "</strong>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</dt>
\t\t\t<dd class=\"info\"><span>";
                // line 40
                echo $this->getAttribute($context["draftrow"], "DATE", []);
                echo "</span></dd>
\t\t</dl>
\t</li>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['draftrow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "
\t</ul>

\t</div>
</div>
";
        }
    }

    public function getTemplateName()
    {
        return "drafts.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 44,  149 => 40,  139 => 36,  136 => 35,  132 => 34,  121 => 33,  110 => 32,  102 => 31,  90 => 27,  86 => 26,  77 => 24,  70 => 20,  66 => 19,  53 => 13,  45 => 8,  41 => 7,  36 => 4,  34 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "drafts.html", "");
    }
}
