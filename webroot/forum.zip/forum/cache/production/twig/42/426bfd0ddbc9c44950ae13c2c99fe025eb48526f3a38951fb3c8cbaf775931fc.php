<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* mcp_forum.html */
class __TwigTemplate_19abad4114a182d37a5a924d360319ced50edd2c9af4f3ed66c68f97e1a66015 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $location = "mcp_header.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("mcp_header.html", "mcp_forum.html", 1)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 2
        echo "
";
        // line 3
        $value = "forum-selection2";
        $context['definition']->set('CUSTOM_FIELDSET_CLASS', $value);
        // line 4
        $location = "jumpbox.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("jumpbox.html", "mcp_forum.html", 4)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 5
        echo "
<h2><a href=\"";
        // line 6
        echo ($context["U_VIEW_FORUM"] ?? null);
        echo "\">";
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORUM");
        echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
        echo " ";
        echo ($context["FORUM_NAME"] ?? null);
        echo "</a></h2>

<form method=\"post\" id=\"mcp\" action=\"";
        // line 8
        echo ($context["S_MCP_ACTION"] ?? null);
        echo "\">

<div class=\"panel\">
\t<div class=\"inner\">

\t<div class=\"action-bar bar-top\">
\t\t<div class=\"pagination\">
\t\t\t";
        // line 15
        echo ($context["TOTAL_TOPICS"] ?? null);
        echo "
\t\t\t";
        // line 16
        if (twig_length_filter($this->env, $this->getAttribute(($context["loops"] ?? null), "pagination", []))) {
            // line 17
            echo "\t\t\t\t";
            $location = "pagination.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("pagination.html", "mcp_forum.html", 17)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 18
            echo "\t\t\t";
        } else {
            // line 19
            echo "\t\t\t\t &bull; ";
            echo ($context["PAGE_NUMBER"] ?? null);
            echo "
\t\t\t";
        }
        // line 21
        echo "\t\t</div>
\t</div>

\t";
        // line 24
        if (twig_length_filter($this->env, $this->getAttribute(($context["loops"] ?? null), "topicrow", []))) {
            // line 25
            echo "\t\t<ul class=\"topiclist";
            if (($context["S_MERGE_SELECT"] ?? null)) {
                echo " missing-column";
            }
            echo "\">
\t\t\t<li class=\"header\">
\t\t\t\t<dl class=\"row-item\">
\t\t\t\t\t<dt><div class=\"list-inner\">";
            // line 28
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPICS");
            echo "</div></dt>
\t\t\t\t\t<dd class=\"posts\">";
            // line 29
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REPLIES");
            echo "</dd>
\t\t\t\t\t<dd class=\"lastpost\"><span>";
            // line 30
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
            echo "</span></dd>
\t\t\t\t\t";
            // line 31
            if ( !($context["S_MERGE_SELECT"] ?? null)) {
                echo "<dd class=\"mark\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MARK");
                echo "</dd>";
            }
            // line 32
            echo "\t\t\t\t</dl>
\t\t\t</li>
\t\t</ul>
\t\t<ul class=\"topiclist cplist";
            // line 35
            if (($context["S_MERGE_SELECT"] ?? null)) {
                echo " missing-column";
            }
            echo "\">

\t\t";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["loops"] ?? null), "topicrow", []));
            foreach ($context['_seq'] as $context["_key"] => $context["topicrow"]) {
                // line 38
                echo "\t\t<li class=\"row";
                if (($this->getAttribute($context["topicrow"], "S_ROW_COUNT", []) % 2 == 1)) {
                    echo " bg1";
                } else {
                    echo " bg2";
                }
                if ($this->getAttribute($context["topicrow"], "S_TOPIC_REPORTED", [])) {
                    echo " reported";
                }
                echo "\">
\t\t\t<dl class=\"row-item ";
                // line 39
                echo $this->getAttribute($context["topicrow"], "TOPIC_IMG_STYLE", []);
                echo "\">
\t\t\t\t<dt ";
                // line 40
                if ($this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", [])) {
                    echo "style=\"background-image: url(";
                    echo ($context["T_ICONS_PATH"] ?? null);
                    echo $this->getAttribute($context["topicrow"], "TOPIC_ICON_IMG", []);
                    echo "); background-repeat: no-repeat;\"";
                }
                echo ">
\t\t\t\t\t";
                // line 41
                if ($this->getAttribute($context["topicrow"], "S_UNREAD_TOPIC", [])) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_NEWEST_POST", []);
                    echo "\" class=\"row-item-link\"></a>";
                }
                // line 42
                echo "\t\t\t\t\t<div class=\"list-inner\">
\t\t\t\t\t";
                // line 43
                // line 44
                echo "\t\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "S_SELECT_TOPIC", [])) {
                    echo "<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_SELECT_TOPIC", []);
                    echo "\" class=\"topictitle\">[ ";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SELECT_MERGE");
                    echo " ]</a>&nbsp;&nbsp; ";
                }
                // line 45
                echo "\t\t\t\t\t";
                // line 46
                echo "\t\t\t\t\t<a href=\"";
                echo $this->getAttribute($context["topicrow"], "U_VIEW_TOPIC", []);
                echo "\" class=\"topictitle\">";
                echo $this->getAttribute($context["topicrow"], "TOPIC_TITLE", []);
                echo "</a>
\t\t\t\t\t";
                // line 47
                // line 48
                echo "\t\t\t\t\t";
                if (($this->getAttribute($context["topicrow"], "S_TOPIC_UNAPPROVED", []) || $this->getAttribute($context["topicrow"], "S_POSTS_UNAPPROVED", []))) {
                    // line 49
                    echo "\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_QUEUE", []);
                    echo "\" title=\"";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_UNAPPROVED");
                    echo "\">
\t\t\t\t\t\t\t<i class=\"icon fa-question fa-fw icon-blue\" aria-hidden=\"true\"></i><span class=\"sr-only\">";
                    // line 50
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_UNAPPROVED");
                    echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t";
                }
                // line 53
                echo "\t\t\t\t\t";
                if (($this->getAttribute($context["topicrow"], "S_TOPIC_DELETED", []) || $this->getAttribute($context["topicrow"], "S_POSTS_DELETED", []))) {
                    // line 54
                    echo "\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_QUEUE", []);
                    echo "\" title=\"";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_DELETED");
                    echo "\">
\t\t\t\t\t\t\t<i class=\"icon fa-recycle fa-fw icon-green\" aria-hidden=\"true\"></i><span class=\"sr-only\">";
                    // line 55
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_DELETED");
                    echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t";
                }
                // line 58
                echo "\t\t\t\t\t";
                if ($this->getAttribute($context["topicrow"], "S_TOPIC_REPORTED", [])) {
                    // line 59
                    echo "\t\t\t\t\t\t<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_MCP_REPORT", []);
                    echo "\" title=\"";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_REPORTED");
                    echo "\">
\t\t\t\t\t\t\t<i class=\"icon fa-exclamation fa-fw icon-red\" aria-hidden=\"true\"></i><span class=\"sr-only\">";
                    // line 60
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("TOPIC_REPORTED");
                    echo "</span>
\t\t\t\t\t\t</a>
\t\t\t\t\t";
                }
                // line 63
                echo "\t\t\t\t\t";
                if (($this->getAttribute($context["topicrow"], "S_MOVED_TOPIC", []) && ($context["S_CAN_DELETE"] ?? null))) {
                    echo "&nbsp;<a href=\"";
                    echo $this->getAttribute($context["topicrow"], "U_DELETE_TOPIC", []);
                    echo "\" class=\"topictitle\">[ ";
                    echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE_SHADOW_TOPIC");
                    echo " ]</a>";
                }
                // line 64
                echo "\t\t\t\t\t<br />
\t\t\t\t\t";
                // line 65
                // line 66
                echo "\t\t\t\t\t<div class=\"responsive-show\" style=\"display: none;\">
\t\t\t\t\t\t";
                // line 67
                if ($this->getAttribute($context["topicrow"], "ATTACH_ICON_IMG", [])) {
                    echo "<i class=\"icon fa-paperclip fa-fw\" aria-hidden=\"true\"></i> ";
                }
                // line 68
                echo "\t\t\t\t\t\t";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
                echo " ";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POST_BY_AUTHOR");
                echo " ";
                echo $this->getAttribute($context["topicrow"], "LAST_POST_AUTHOR_FULL", []);
                echo " &laquo; ";
                echo $this->getAttribute($context["topicrow"], "LAST_POST_TIME", []);
                echo "<br />
\t\t\t\t\t</div>
\t\t\t\t\t<span class=\"responsive-show left-box\" style=\"display: none;\">";
                // line 70
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REPLIES");
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("COLON");
                echo " <strong>";
                echo $this->getAttribute($context["topicrow"], "REPLIES", []);
                echo "</strong></span>

\t\t\t\t\t";
                // line 72
                if (twig_length_filter($this->env, $this->getAttribute($context["topicrow"], "pagination", []))) {
                    // line 73
                    echo "\t\t\t\t\t<div class=\"pagination\">
\t\t\t\t\t\t<ul>
\t\t\t\t\t\t";
                    // line 75
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["topicrow"], "pagination", []));
                    foreach ($context['_seq'] as $context["_key"] => $context["pagination"]) {
                        // line 76
                        echo "\t\t\t\t\t\t\t";
                        if ($this->getAttribute($context["pagination"], "S_IS_PREV", [])) {
                            // line 77
                            echo "\t\t\t\t\t\t\t";
                        } elseif ($this->getAttribute($context["pagination"], "S_IS_CURRENT", [])) {
                            echo "<li class=\"active\"><span>";
                            echo $this->getAttribute($context["pagination"], "PAGE_NUMBER", []);
                            echo "</span></li>
\t\t\t\t\t\t\t";
                        } elseif ($this->getAttribute(                        // line 78
$context["pagination"], "S_IS_ELLIPSIS", [])) {
                            echo "<li class=\"ellipsis\"><span>";
                            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("ELLIPSIS");
                            echo "</span></li>
\t\t\t\t\t\t\t";
                        } elseif ($this->getAttribute(                        // line 79
$context["pagination"], "S_IS_NEXT", [])) {
                            // line 80
                            echo "\t\t\t\t\t\t\t";
                        } else {
                            echo "<li><a href=\"";
                            echo $this->getAttribute($context["pagination"], "PAGE_URL", []);
                            echo "\">";
                            echo $this->getAttribute($context["pagination"], "PAGE_NUMBER", []);
                            echo "</a></li>
\t\t\t\t\t\t\t";
                        }
                        // line 82
                        echo "\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pagination'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 83
                    echo "\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t\t";
                }
                // line 86
                echo "
\t\t\t\t\t<div class=\"responsive-hide\">
\t\t\t\t\t\t";
                // line 88
                if ($this->getAttribute($context["topicrow"], "ATTACH_ICON_IMG", [])) {
                    echo "<i class=\"icon fa-paperclip fa-fw\" aria-hidden=\"true\"></i> ";
                }
                // line 89
                echo "\t\t\t\t\t\t";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POST_BY_AUTHOR");
                echo " ";
                echo $this->getAttribute($context["topicrow"], "TOPIC_AUTHOR_FULL", []);
                echo " &raquo; ";
                echo $this->getAttribute($context["topicrow"], "FIRST_POST_TIME", []);
                echo "
\t\t\t\t\t</div>
\t\t\t\t\t";
                // line 91
                // line 92
                echo "\t\t\t\t\t</div>
\t\t\t\t</dt>
\t\t\t\t<dd class=\"posts\">";
                // line 94
                echo $this->getAttribute($context["topicrow"], "REPLIES", []);
                echo " <dfn>";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("REPLIES");
                echo "</dfn></dd>
\t\t\t\t<dd class=\"lastpost\"><span><dfn>";
                // line 95
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LAST_POST");
                echo " </dfn>";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("POST_BY_AUTHOR");
                echo " ";
                echo $this->getAttribute($context["topicrow"], "LAST_POST_AUTHOR_FULL", []);
                echo "<br />";
                echo $this->getAttribute($context["topicrow"], "LAST_POST_TIME", []);
                echo "</span></dd>
\t\t\t\t";
                // line 96
                if ( !($context["S_MERGE_SELECT"] ?? null)) {
                    // line 97
                    echo "\t\t\t\t<dd class=\"mark\">
\t\t\t\t\t";
                    // line 98
                    if ( !$this->getAttribute($context["topicrow"], "S_MOVED_TOPIC", [])) {
                        echo "<input type=\"checkbox\" name=\"topic_id_list[]\" value=\"";
                        echo $this->getAttribute($context["topicrow"], "TOPIC_ID", []);
                        echo "\"";
                        if ($this->getAttribute($context["topicrow"], "S_TOPIC_CHECKED", [])) {
                            echo " checked=\"checked\"";
                        }
                        echo " />";
                    } else {
                        echo "&nbsp;";
                    }
                    // line 99
                    echo "\t\t\t\t</dd>
\t\t\t\t";
                }
                // line 101
                echo "\t\t\t</dl>
\t\t</li>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['topicrow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 104
            echo "\t\t</ul>
\t";
        } else {
            // line 106
            echo "\t\t<ul class=\"topiclist\">
\t\t\t<li><p class=\"notopics\">";
            // line 107
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("NO_TOPICS");
            echo "</p></li>
\t\t</ul>
\t";
        }
        // line 110
        echo "
\t<div class=\"action-bar bottom\">
\t\t";
        // line 112
        $location = "display_options.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("display_options.html", "mcp_forum.html", 112)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 113
        echo "
\t\t<div class=\"pagination\">
\t\t\t";
        // line 115
        echo ($context["TOTAL_TOPICS"] ?? null);
        echo "
\t\t\t";
        // line 116
        if (twig_length_filter($this->env, $this->getAttribute(($context["loops"] ?? null), "pagination", []))) {
            // line 117
            echo "\t\t\t\t";
            $location = "pagination.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("pagination.html", "mcp_forum.html", 117)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 118
            echo "\t\t\t";
        } else {
            // line 119
            echo "\t\t\t\t &bull; ";
            echo ($context["PAGE_NUMBER"] ?? null);
            echo "
\t\t\t";
        }
        // line 121
        echo "\t\t</div>
\t</div>

\t</div>
</div>

";
        // line 127
        // line 128
        echo "<fieldset class=\"display-actions\">
\t";
        // line 129
        if ( !($context["S_MERGE_SELECT"] ?? null)) {
            // line 130
            echo "\t<select name=\"action\">
\t\t<option value=\"\" selected=\"selected\">";
            // line 131
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SELECT_ACTION");
            echo "</option>
\t\t";
            // line 132
            if (($context["S_CAN_DELETE"] ?? null)) {
                echo "<option value=\"delete_topic\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("DELETE");
                echo "</option>";
            }
            // line 133
            echo "\t\t";
            if (($context["S_CAN_RESTORE"] ?? null)) {
                echo "<option value=\"restore_topic\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RESTORE");
                echo "</option>";
            }
            // line 134
            echo "\t\t";
            if (($context["S_CAN_MERGE"] ?? null)) {
                echo "<option value=\"merge_topics\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MERGE");
                echo "</option>";
            }
            // line 135
            echo "\t\t";
            if (($context["S_CAN_MOVE"] ?? null)) {
                echo "<option value=\"move\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MOVE");
                echo "</option>";
            }
            // line 136
            echo "\t\t";
            if (($context["S_CAN_FORK"] ?? null)) {
                echo "<option value=\"fork\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("FORK");
                echo "</option>";
            }
            // line 137
            echo "\t\t";
            if (($context["S_CAN_LOCK"] ?? null)) {
                echo "<option value=\"lock\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("LOCK");
                echo "</option><option value=\"unlock\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNLOCK");
                echo "</option>";
            }
            // line 138
            echo "\t\t";
            if (($context["S_CAN_SYNC"] ?? null)) {
                echo "<option value=\"resync\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("RESYNC");
                echo "</option>";
            }
            // line 139
            echo "\t\t";
            if (($context["S_CAN_MAKE_NORMAL"] ?? null)) {
                echo "<option value=\"make_normal\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MAKE_NORMAL");
                echo "</option>";
            }
            // line 140
            echo "\t\t";
            if (($context["S_CAN_MAKE_STICKY"] ?? null)) {
                echo "<option value=\"make_sticky\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MAKE_STICKY");
                echo "</option>";
            }
            // line 141
            echo "\t\t";
            if (($context["S_CAN_MAKE_ANNOUNCE"] ?? null)) {
                echo "<option value=\"make_announce\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MAKE_ANNOUNCE");
                echo "</option>";
            }
            // line 142
            echo "\t\t";
            if (($context["S_CAN_MAKE_ANNOUNCE_GLOBAL"] ?? null)) {
                echo "<option value=\"make_global\">";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MAKE_GLOBAL");
                echo "</option>";
            }
            // line 143
            echo "\t\t";
            // line 144
            echo "\t</select>
\t<input class=\"button2\" type=\"submit\" value=\"";
            // line 145
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("SUBMIT");
            echo "\" />
\t<div><a href=\"#\" onclick=\"marklist('mcp', 'topic_id_list', true); return false;\">";
            // line 146
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("MARK_ALL");
            echo "</a> :: <a href=\"#\" onclick=\"marklist('mcp', 'topic_id_list', false); return false;\">";
            echo $this->env->getExtension('phpbb\template\twig\extension')->lang("UNMARK_ALL");
            echo "</a></div>
\t";
        }
        // line 148
        echo "\t";
        echo ($context["S_FORM_TOKEN"] ?? null);
        echo "
</fieldset>
";
        // line 150
        // line 151
        echo "</form>

";
        // line 153
        $location = "mcp_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("mcp_footer.html", "mcp_forum.html", 153)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
    }

    public function getTemplateName()
    {
        return "mcp_forum.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  607 => 153,  603 => 151,  602 => 150,  596 => 148,  589 => 146,  585 => 145,  582 => 144,  580 => 143,  573 => 142,  566 => 141,  559 => 140,  552 => 139,  545 => 138,  536 => 137,  529 => 136,  522 => 135,  515 => 134,  508 => 133,  502 => 132,  498 => 131,  495 => 130,  493 => 129,  490 => 128,  489 => 127,  481 => 121,  475 => 119,  472 => 118,  459 => 117,  457 => 116,  453 => 115,  449 => 113,  437 => 112,  433 => 110,  427 => 107,  424 => 106,  420 => 104,  412 => 101,  408 => 99,  396 => 98,  393 => 97,  391 => 96,  381 => 95,  375 => 94,  371 => 92,  370 => 91,  360 => 89,  356 => 88,  352 => 86,  347 => 83,  341 => 82,  331 => 80,  329 => 79,  323 => 78,  316 => 77,  313 => 76,  309 => 75,  305 => 73,  303 => 72,  295 => 70,  283 => 68,  279 => 67,  276 => 66,  275 => 65,  272 => 64,  263 => 63,  257 => 60,  250 => 59,  247 => 58,  241 => 55,  234 => 54,  231 => 53,  225 => 50,  218 => 49,  215 => 48,  214 => 47,  207 => 46,  205 => 45,  196 => 44,  195 => 43,  192 => 42,  186 => 41,  177 => 40,  173 => 39,  161 => 38,  157 => 37,  150 => 35,  145 => 32,  139 => 31,  135 => 30,  131 => 29,  127 => 28,  118 => 25,  116 => 24,  111 => 21,  105 => 19,  102 => 18,  89 => 17,  87 => 16,  83 => 15,  73 => 8,  63 => 6,  60 => 5,  48 => 4,  45 => 3,  42 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "mcp_forum.html", "");
    }
}
