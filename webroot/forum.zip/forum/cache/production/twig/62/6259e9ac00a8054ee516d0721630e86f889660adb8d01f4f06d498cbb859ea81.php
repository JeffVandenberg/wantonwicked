<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* topic_notify.txt */
class __TwigTemplate_3565ea4c863c660bae92c2b1e6b01ea01662b35f71092aa1590f030e05a36a32 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "Subject: Topic reply notification - \"";
        echo ($context["TOPIC_TITLE"] ?? null);
        echo "\"
List-Unsubscribe: <";
        // line 2
        echo ($context["U_STOP_WATCHING_TOPIC"] ?? null);
        echo ">

Hello ";
        // line 4
        echo ($context["USERNAME"] ?? null);
        echo ",

You are receiving this notification because you are watching the topic \"";
        // line 6
        echo ($context["TOPIC_TITLE"] ?? null);
        echo "\" at \"";
        echo ($context["SITENAME"] ?? null);
        echo "\". This topic has received a reply";
        if ((($context["AUTHOR_NAME"] ?? null) != "")) {
            echo " by ";
            echo ($context["AUTHOR_NAME"] ?? null);
        }
        echo " since your last visit. No more notifications will be sent until you visit the topic.

If you want to view the newest post made since your last visit, click the following link:
";
        // line 9
        echo ($context["U_NEWEST_POST"] ?? null);
        echo "

If you want to view the topic, click the following link:
";
        // line 12
        echo ($context["U_TOPIC"] ?? null);
        echo "

If you want to view the forum, click the following link:
";
        // line 15
        echo ($context["U_FORUM"] ?? null);
        echo "

If you no longer wish to watch this topic you can either click the \"Unsubscribe topic\" link found at the bottom of the topic above, or by clicking the following link:
";
        // line 18
        echo ($context["U_STOP_WATCHING_TOPIC"] ?? null);
        echo "

";
        // line 20
        echo ($context["EMAIL_SIG"] ?? null);
        echo "
";
    }

    public function getTemplateName()
    {
        return "topic_notify.txt";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 20,  76 => 18,  70 => 15,  64 => 12,  58 => 9,  45 => 6,  40 => 4,  35 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "topic_notify.txt", "");
    }
}
