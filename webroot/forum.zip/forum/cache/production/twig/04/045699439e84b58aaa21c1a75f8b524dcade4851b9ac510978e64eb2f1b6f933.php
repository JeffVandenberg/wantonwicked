<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @alfredoramos_simplespoiler/event/overall_footer_body_after.html */
class __TwigTemplate_0b43c01865145f891da566e148369fb93ef8fd4bf4c0f09112554afa96c54179 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if ( !($context["INCLUDED_SPOILER_JS"] ?? null)) {
            // line 2
            $asset_file = "@alfredoramos_simplespoiler/js/spoiler.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
            }
            
            if ($asset->is_relative()) {
                $asset->add_assets_version('40');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 3
            echo "<script type=\"text/javascript\">
(function(\$) {
\t'use strict';
\t\$(document.body).initSpoilers({
\t\tlang: {
\t\t\tshow: '";
            // line 8
            echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("SPOILER_SHOW"), "js");
            echo "',
\t\t\thide: '";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('phpbb\template\twig\extension')->lang("SPOILER_HIDE"), "js");
            echo "'
\t\t}
\t});
})(jQuery);
</script>
";
            // line 14
            $context["INCLUDED_SPOILER_JS"] = true;
        }
    }

    public function getTemplateName()
    {
        return "@alfredoramos_simplespoiler/event/overall_footer_body_after.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 14,  57 => 9,  53 => 8,  46 => 3,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@alfredoramos_simplespoiler/event/overall_footer_body_after.html", "");
    }
}
