<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @phpbb_boardannouncements/event/acp_overall_footer_after.html */
class __TwigTemplate_2538a9675b8655a9500f87be26b4437a98639413d61c02428fda1cb5b536ea73 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if (($context["S_BOARD_ANNOUNCEMENTS"] ?? null)) {
            // line 2
            echo "
";
            // line 3
            if ( !$this->getAttribute(($context["definition"] ?? null), "INCLUDED_COLPICKJS", [])) {
                // line 4
                echo "\t";
                $asset_file = "@phpbb_boardannouncements/colpick.js";
                $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
                if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                    $asset_path = $asset->get_path();                    $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                    if (!file_exists($local_file)) {
                        $local_file = $this->getEnvironment()->findTemplate($asset_path);
                        $asset->set_path($local_file, true);
                    }
                }
                
                if ($asset->is_relative()) {
                    $asset->add_assets_version('40');
                }
                $this->getEnvironment()->get_assets_bag()->add_script($asset);                // line 5
                echo "\t";
                $value = true;
                $context['definition']->set('INCLUDED_COLPICKJS', $value);
            }
            // line 7
            echo "
";
            // line 8
            if ( !$this->getAttribute(($context["definition"] ?? null), "INCLUDED_DATETIMEPICKERJS", [])) {
                // line 9
                echo "\t";
                $asset_file = "@phpbb_boardannouncements/datetimepicker/jquery.datetimepicker.full.min.js";
                $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
                if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                    $asset_path = $asset->get_path();                    $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                    if (!file_exists($local_file)) {
                        $local_file = $this->getEnvironment()->findTemplate($asset_path);
                        $asset->set_path($local_file, true);
                    }
                }
                
                if ($asset->is_relative()) {
                    $asset->add_assets_version('40');
                }
                $this->getEnvironment()->get_assets_bag()->add_script($asset);                // line 10
                echo "\t";
                $value = true;
                $context['definition']->set('INCLUDED_DATETIMEPICKERJS', $value);
            }
            // line 12
            echo "
<script>
jQuery(function(\$) {
\tvar bgcolor = '";
            // line 15
            echo ($context["BOARD_ANNOUNCEMENTS_BGCOLOR"] ?? null);
            echo "';
\t\$('#board_announcements_bgcolor').colpick({
\t\tlayout: 'hex',
\t\tsubmit: 0,
\t\tonBeforeShow: function() {
\t\t\tif (bgcolor !== '') {
\t\t\t\t\$(this).colpickSetColor(bgcolor);
\t\t\t\tbgcolor = '';
\t\t\t}
\t\t},
\t\tonChange: function(hsb, hex, rgb, el, bySetColor) {
\t\t\t\$(el).css({
\t\t\t\t'border-right-color': '#' + hex,
\t\t\t\t'border-right-width': '20px',
\t\t\t\t'border-right-type': 'solid'
\t\t\t});
\t\t\tif (!bySetColor) {
\t\t\t\t\$(el).val(hex);
\t\t\t}
\t\t}
\t}).keyup(function() {
\t\t\$(this).colpickSetColor(this.value || 'ffffff');
\t});
\t\$('#board_announcements_expiry').datetimepicker({
\t\tformat:'";
            // line 39
            echo twig_escape_filter($this->env, ($context["PICKER_DATE_FORMAT"] ?? null), "js");
            echo "',
\t\tvalidateOnBlur: false,
\t\tminDate: 0
\t});
\t\$.datetimepicker.setLocale('";
            // line 43
            echo ($context["S_USER_LANG"] ?? null);
            echo "')
});
</script>

";
        }
    }

    public function getTemplateName()
    {
        return "@phpbb_boardannouncements/event/acp_overall_footer_after.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 43,  114 => 39,  87 => 15,  82 => 12,  77 => 10,  62 => 9,  60 => 8,  57 => 7,  52 => 5,  37 => 4,  35 => 3,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@phpbb_boardannouncements/event/acp_overall_footer_after.html", "");
    }
}
