<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* privmsg_notify.txt */
class __TwigTemplate_c6e247e21269bcaef20a493bf5301811d88f59320ae5cfce8066149280e59ce9 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "Subject: New private message has arrived

Hello ";
        // line 3
        echo ($context["USERNAME"] ?? null);
        echo ",

You have received a new private message from \"";
        // line 5
        echo ($context["AUTHOR_NAME"] ?? null);
        echo "\" to your account on \"";
        echo ($context["SITENAME"] ?? null);
        echo "\" with the following subject:

";
        // line 7
        echo ($context["SUBJECT"] ?? null);
        echo "

You can view your new message by clicking on the following link:

";
        // line 11
        echo ($context["U_VIEW_MESSAGE"] ?? null);
        echo "

You have requested that you be notified on this event, remember that you can always choose not to be notified of new messages by changing the appropriate setting in your profile.

";
        // line 15
        echo ($context["EMAIL_SIG"] ?? null);
        echo "
";
    }

    public function getTemplateName()
    {
        return "privmsg_notify.txt";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 15,  53 => 11,  46 => 7,  39 => 5,  34 => 3,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "privmsg_notify.txt", "");
    }
}
