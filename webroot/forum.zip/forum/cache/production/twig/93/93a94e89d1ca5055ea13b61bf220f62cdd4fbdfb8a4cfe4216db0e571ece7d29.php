<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @senky_removesubjectfromreplies/event/posting_editor_subject_after.html */
class __TwigTemplate_9771c31acf952367659004aba51061bcf809c60464de43cdb19472c08ac7554a extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if (( !($context["S_PRIVMSGS"] ?? null) &&  !($context["S_NEW_MESSAGE"] ?? null))) {
            // line 2
            echo "</div>

";
            // line 4
            if (((($context["S_POST_ACTION"] ?? null) || ($context["S_PRIVMSGS"] ?? null)) || ($context["S_EDIT_DRAFT"] ?? null))) {
                // line 5
                echo "\t";
                if ((($context["CAPTCHA_TEMPLATE"] ?? null) && ($context["S_CONFIRM_CODE"] ?? null))) {
                    // line 6
                    echo "\t\t";
                    $value = 3;
                    $context['definition']->set('CAPTCHA_TAB_INDEX', $value);
                    // line 7
                    echo "\t\t";
                    $location = (("" . ($context["CAPTCHA_TEMPLATE"] ?? null)) . "");
                    $namespace = false;
                    if (strpos($location, '@') === 0) {
                        $namespace = substr($location, 1, strpos($location, '/') - 1);
                        $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                        $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
                    }
                    $this->loadTemplate((("" . ($context["CAPTCHA_TEMPLATE"] ?? null)) . ""), "@senky_removesubjectfromreplies/event/posting_editor_subject_after.html", 7)->display($context);
                    if ($namespace) {
                        $this->env->setNamespaceLookUpOrder($previous_look_up_order);
                    }
                    // line 8
                    echo "\t";
                }
            }
        }
    }

    public function getTemplateName()
    {
        return "@senky_removesubjectfromreplies/event/posting_editor_subject_after.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 8,  45 => 7,  41 => 6,  38 => 5,  36 => 4,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@senky_removesubjectfromreplies/event/posting_editor_subject_after.html", "");
    }
}
