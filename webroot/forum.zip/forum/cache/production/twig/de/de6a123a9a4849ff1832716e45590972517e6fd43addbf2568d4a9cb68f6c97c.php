<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blank_ww4.tpl */
class __TwigTemplate_f68fd83afe072cf75d6ab0dc47115b806a093b09063227141a284b738c0234ec extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>
    <title>";
        // line 5
        echo ($context["PAGE_TITLE"] ?? null);
        echo "</title>
    <META NAME=\"copyright\" content=\"(c) 2013 Jeff Vandenberg\">
    <META NAME=\"ROBOTS\" CONTENT=\"noimageindex,follow\">
    <link type=\"text/css\" href=\"css/ww5.css\" rel=\"Stylesheet\"/>
    <link type=\"text/css\" href=\"css/gaming-sandbox.css\" rel=\"Stylesheet\"/>
    <link type=\"text/css\" href=\"css/wanton/jquery-ui.min.css\" rel=\"stylesheet\"/>
    <link type=\"text/css\" href=\"css/wanton/jquery.ui.menubar.css\" rel=\"stylesheet\"/>
    <script type=\"text/javascript\" src=\"js/jquery-1.11.3.min.js\"></script>
    <script type=\"text/javascript\" src=\"js/jquery-ui.min.js\"></script>
    <script type=\"text/javascript\" src=\"js/jquery.ui.menubar.js\"></script>
    <script type=\"text/javascript\" src=\"js/wanton.js\"></script>
</head>
";
        // line 17
        echo ($context["JAVA_SCRIPT"] ?? null);
        echo "
<body>
<div id=\"widthsetter\">
    <div id=\"content\">
        <div id=\"pagetitle\">
            ";
        // line 22
        echo ($context["CONTENT_HEADER"] ?? null);
        echo "
        </div>
        <div id=\"contenta\">
            <div id=\"contentb\" class=\"contentbox\">
                ";
        // line 26
        if (($context["FLASH_MESSAGE"] ?? null)) {
            // line 27
            echo "                <div class=\"flash-message\">
                    ";
            // line 28
            echo ($context["FLASH_MESSAGE"] ?? null);
            echo "
                </div>
                ";
        }
        // line 31
        echo "                ";
        echo ($context["PAGE_CONTENT"] ?? null);
        echo "
            </div>
        </div>
    </div>
</div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "blank_ww4.tpl";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 31,  71 => 28,  68 => 27,  66 => 26,  59 => 22,  51 => 17,  36 => 5,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "blank_ww4.tpl", "");
    }
}
