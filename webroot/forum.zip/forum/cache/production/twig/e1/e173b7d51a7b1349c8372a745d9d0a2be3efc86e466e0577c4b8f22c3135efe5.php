<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main_ww4.tpl */
class __TwigTemplate_51bd453b7a7f6f83f76e1c24698f33147962249a8907ba5740dd6b0e6146831b extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-115948072-1\"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-115948072-1');
    </script>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>
    <title>";
        // line 14
        echo ($context["PAGE_TITLE"] ?? null);
        echo "</title>
    <META NAME=\"copyright\" content=\"(c) <?php echo date('Y'); ?> Jeff Vandenberg\">
    <META NAME=\"ROBOTS\" CONTENT=\"noimageindex,follow\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <link type=\"text/css\" href=\"/css/app.css\" rel=\"Stylesheet\"/>
    <link href=\"https://fonts.googleapis.com/css?family=Marcellus+SC\" rel=\"stylesheet\">
    <script type=\"text/javascript\" src=\"/js/jquery.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/jquery.autocomplete.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/jquery.datetimepicker.full.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/tinymce/tinymce.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/server_time.js\"></script>
    <script type=\"text/javascript\" src=\"/js/foundation.min.js\"></script>
    <script type=\"text/javascript\" src=\"/js/wanton.js\"></script>
</head>
<body>
<div id=\"header\">
    <div class=\"title-bar\" data-hide-for=\"medium\" data-responsive-toggle=\"nav-top\">
        <button class=\"menu-icon\" type=\"button\" data-toggle></button>
        <div class=\"title-logo\" role=\"banner\">
            <a href=\"/\" title=\"Wanton Wicked\">
                <img src=\"/img/ww_logo_50x50.png\" alt=\"Wanton Wicked Logo\"/>
            </a>
        </div>
    </div>
    <nav id=\"nav-top\" class=\"top-bar\" data-sticky data-options=\"marginTop:0;\" style=\"width:100%\"
         data-top-anchor=\"main-content\">
        <ul class=\"menu\">
            <li class=\"topbar-title title-logo show-for-medium\"
                role=\"banner\">
                <a href=\"/\" title=\"Wanton Wicked\">
                    <img src=\"/img/ww_logo_50x50.png\" alt=\"Wanton Wicked Logo\"/>
                </a>
            </li>
        </ul>
        <div class=\"top-bar-left\">
            ";
        // line 49
        echo ($context["MENU_BAR"] ?? null);
        echo "
        </div>
        <div class=\"top-bar-right\">
            <span id=\"server-time\"></span>
            ";
        // line 53
        if ($this->getAttribute(($context["USER_INFO"] ?? null), "logged_in", [])) {
            // line 54
            echo "                ";
            if ($this->getAttribute(($context["USER_INFO"] ?? null), "new_request_count", [])) {
                // line 55
                echo "                <a href=\"/requests/st-dashboard\" class=\"button-badge\">
                    <i class=\"fa fi-clipboard storyteller-action\" title=\"ST Request Dashboard\"></i>
                    <span class=\"badge badge-primary warning\" title=\"New Requests\">";
                // line 57
                echo $this->getAttribute(($context["USER_INFO"] ?? null), "new_request_count", []);
                echo "</span>
                </a>
                ";
            }
            // line 60
            echo "                <a href=\"/requests\" class=\"button-badge\">
                    <i class=\"fa fi-clipboard\" title=\"Your Requests\"></i>
                    ";
            // line 62
            if ($this->getAttribute(($context["USER_INFO"] ?? null), "request_count", [])) {
                // line 63
                echo "                    <span class=\"badge badge-primary warning\" title=\"Open Requests\">";
                echo $this->getAttribute(($context["USER_INFO"] ?? null), "request_count", []);
                echo "</span>
                    ";
            }
            // line 65
            echo "                </a>
                <button class=\"button\" type=\"button\" data-toggle=\"user-dropdown\">
                    ";
            // line 67
            echo $this->getAttribute(($context["USER_INFO"] ?? null), "username", []);
            echo "
                </button>
                <div class=\"dropdown-pane\" id=\"user-dropdown\" data-dropdown>
                    <div><a href=\"/forum/ucp.php\">User Control Panel</a></div>
                    <div><a href=\"";
            // line 71
            echo $this->getAttribute(($context["USER_INFO"] ?? null), "logout_link", []);
            echo "\">Logout</a></div>
                </div>
            ";
        } else {
            // line 74
            echo "                <a href=\"/forum/ucp.php?mode=login&redirect=";
            echo $this->getAttribute(($context["USER_INFO"] ?? null), "redirect", []);
            echo "\">Login</a>
                <a href=\"/forum/ucp.php?mode=register&redirect=";
            // line 75
            echo $this->getAttribute(($context["USER_INFO"] ?? null), "redirect", []);
            echo "\">Register</a>
            ";
        }
        // line 77
        echo "        </div>
    </nav>
</div>
<div class=\"widthsetter\" id=\"main-content\">
    <div id=\"content\">
        <div id=\"pagetitle\">
            ";
        // line 83
        echo ($context["CONTENT_HEADER"] ?? null);
        echo "
        </div>
        <div id=\"contenta\" class=\"contentbox\">
            ";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["loops"] ?? null), "messages", []));
        foreach ($context['_seq'] as $context["_key"] => $context["messages"]) {
            // line 87
            echo "            <div class=\"flash-message\">
                ";
            // line 88
            echo $this->getAttribute($context["messages"], "message", []);
            echo "
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 91
        echo "            ";
        echo ($context["PAGE_CONTENT"] ?? null);
        echo "
        </div>
    </div>
</div>
<div id=\"footer\">
    <div class=\"row\">
        <div class=\"small-12 column text-center\">
            <div style=\"font-size: 9px;\">The Storytelling System, Beast the Primordial, Changeling
                the Lost, Chronicles of Darkness, Demon the Descent, Mage the Awakening, Vampire the Requiem,
                and
                Werewolf the Forsaken
                &copy;2014-2016 CCP hf and published by <a href=\"http://theonyxpath.com/\" target=\"_blank\">Onyx
                    Path
                    Publishing</a>.<br>
                Produced by Jeff Vandenberg. Layout and Design by Jill Arden &copy; 2016
                Build # ";
        // line 106
        echo ($context["BUILD_NUMBER"] ?? null);
        echo "
            </div>
        </div>
    </div>
</div>
<img src=\"/img/indicator.gif\" id=\"busy-indicator\" alt=\"\"/>
";
        // line 112
        echo ($context["JAVA_SCRIPT"] ?? null);
        echo "
<script>
    wantonWickedTime.serverTime = ";
        // line 114
        echo ($context["SERVER_TIME"] ?? null);
        echo ";
</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "main_ww4.tpl";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  207 => 114,  202 => 112,  193 => 106,  174 => 91,  165 => 88,  162 => 87,  158 => 86,  152 => 83,  144 => 77,  139 => 75,  134 => 74,  128 => 71,  121 => 67,  117 => 65,  111 => 63,  109 => 62,  105 => 60,  99 => 57,  95 => 55,  92 => 54,  90 => 53,  83 => 49,  45 => 14,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "main_ww4.tpl", "");
    }
}
