<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @phpbb_boardannouncements/event/overall_header_content_before.html */
class __TwigTemplate_558a34b7d20dbad1a6dbfe92fd0faaec1db992a01377a704ca25fd02830a274e extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if (($context["S_BOARD_ANNOUNCEMENT"] ?? null)) {
            // line 2
            echo "\t";
            $asset_file = "@phpbb_boardannouncements/js/boardannouncements.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
            }
            
            if ($asset->is_relative()) {
                $asset->add_assets_version('40');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 3
            echo "\t<div id=\"phpbb_announcement\"";
            if (($context["BOARD_ANNOUNCEMENT_BGCOLOR"] ?? null)) {
                echo " style=\"background-color:#";
                echo ($context["BOARD_ANNOUNCEMENT_BGCOLOR"] ?? null);
                echo "\"";
            }
            echo ">
\t\t";
            // line 4
            if (($context["S_BOARD_ANNOUNCEMENT_DISMISS"] ?? null)) {
                echo "<a href=\"";
                echo ($context["U_BOARD_ANNOUNCEMENT_CLOSE"] ?? null);
                echo "\" data-ajax=\"close_announcement\" data-overlay=\"false\" class=\"close clearfix\" title=\"";
                echo $this->env->getExtension('phpbb\template\twig\extension')->lang("BOARD_ANNOUNCEMENT_CLOSE");
                echo "\"></a>";
            }
            // line 5
            echo "\t\t<div>";
            echo ($context["BOARD_ANNOUNCEMENT"] ?? null);
            echo "</div>
\t</div>
";
        }
    }

    public function getTemplateName()
    {
        return "@phpbb_boardannouncements/event/overall_header_content_before.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 5,  56 => 4,  47 => 3,  32 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@phpbb_boardannouncements/event/overall_header_content_before.html", "");
    }
}
