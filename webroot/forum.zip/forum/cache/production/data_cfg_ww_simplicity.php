<?php exit; ?>
1591225815
282
a:6:{s:4:"name";s:17:"Wanton Simplicity";s:9:"copyright";s:91:"Created by Arty (Vjacheslav Trushkin), http://www.artodia.com/, Modified by Gabriel Fischer";s:13:"style_version";s:5:"3.2.1";s:13:"phpbb_version";s:5:"3.2.1";s:6:"parent";s:10:"Simplicity";s:8:"filetime";i:1544031170;}