<?php exit; ?>
1564947679
SELECT * FROM phpbb_styles s WHERE s.style_id = 22
391
a:1:{i:0;a:8:{s:8:"style_id";s:2:"22";s:10:"style_name";s:17:"Wanton Simplicity";s:15:"style_copyright";s:91:"Created by Arty (Vjacheslav Trushkin), http://www.artodia.com/, Modified by Gabriel Fischer";s:12:"style_active";s:1:"1";s:10:"style_path";s:13:"ww_simplicity";s:15:"bbcode_bitfield";s:4:"//g=";s:15:"style_parent_id";s:2:"16";s:17:"style_parent_tree";s:20:"prosilver/simplicity";}}